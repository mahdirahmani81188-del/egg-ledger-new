EggLedger Android build package

This is an initial Android WebView wrapper around the recovered Persian-dated HTML prototype.
It is NOT yet the final accounting release. Before business use, inventory/sales rules and backup/restore must be reviewed and tested.

GitHub Actions workflow is included. Upload the CONTENTS of this folder to the root of a new GitHub repository (not the ZIP as a single file).
The workflow builds a debug APK after push to main/master, or can be started manually from Actions.

APK artifact: EggLedger-debug-APK
Expected APK file: app-debug.apk
