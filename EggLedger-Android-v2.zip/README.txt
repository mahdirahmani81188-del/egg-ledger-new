EggLedger Android v2 - revised inventory and sales model

The Android project is inside eggledger_build/.
The GitHub Actions workflow is inside .github/workflows/build.yml.

Business rules implemented:
- Purchases are entered only as full cartons.
- Every carton contains exactly 6 trays.
- Opening cartons moves stock from sealed cartons to open trays (1 carton -> 6 trays); it is not a purchase or sale.
- Carton sales reduce sealed-carton stock only.
- Tray sales reduce open-tray stock only.
- Carton and tray sale prices, revenue, cost, and profit are reported separately.
- FIFO costing is maintained per purchase lot.
- Persian digits and Persian-calendar dates are retained.
- Existing legacy kilogram-based records are preserved and shown as legacy stock.

To build: upload the contents of this ZIP to the repository root, then run the Build EggLedger APK workflow.
Artifact name: EggLedger-debug-APK
